package Java6.Service;

import java.util.List;

import Java6.Entity.Role;

public interface RoleService {

	public List<Role> findAll();

}
