package Java6.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class loginController {

	@RequestMapping("/login/form")
	public String Login(Model model) {
		//model.addAttribute("message", "Vui Lòng Đăng Nhập!");
		return "layout/login";
	}
	
	@RequestMapping("/security/login/form")
	public String LoginForm(Model model) {
		model.addAttribute("message", "Vui Lòng Đăng Nhập!");
		return "layout/login";
	}
	
	@RequestMapping("/security/login/success")
	public String LoginSuccess(Model model) {
		model.addAttribute("message", "Đăng Nhập Thành Công!");
		//return "forward:/auth/login/form";
		return "layout/login";
	}
	
	@RequestMapping("/security/login/error")
	public String LoginError(Model model) {
		model.addAttribute("message", "Sai Thông Tin Đăng Nhập!");
		//return "forward:/auth/login/form";
		return "layout/login";
	}
	
	@RequestMapping("/security/unauthoried")
	public String unauthoried(Model model) {
		model.addAttribute("message", "Không Có Quyền Truy Cập");
		//return "forward:/auth/login/form";
		return "layout/login";
	}
	
	@RequestMapping("/security/logoff/success")
	public String logoff(Model model) {
		model.addAttribute("message", "Bạn Đã Đăng Xuất!");
		//return "forward:/auth/login/form";
		return "layout/login";
	}

}
