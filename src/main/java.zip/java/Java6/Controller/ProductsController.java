package Java6.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Java6.Entity.Product;
import Java6.Service.ProductService;

@Controller
public class ProductsController {

	@Autowired
	ProductService productService;
	
	@Autowired
	SessionService session;
	
	@RequestMapping("/product/list")
	public String list(Model model, @RequestParam("cid") Optional<String> cid ,@RequestParam("p") Optional<Integer> p) {
		
        if (cid.isPresent()) {
        	session.set("cid", cid.get());
        	Pageable pageable = PageRequest.of(p.orElse(0), 8);
			//List<Product> list = productService.findByCategory(cid.get());
        	Page<Product> list = productService.findByCategoryPage(session.get("cid"),pageable);
			model.addAttribute("items", list);
			
			session.set("cid", cid.get());
			
			System.out.println("cid=" + session.get("cid"));
			return "layout/shop";
		}else {
			Pageable pageable = PageRequest.of(p.orElse(0), 8);
			//List<Product> list = productService.findAll();
			Page<Product> list = productService.finPage(pageable);
			model.addAttribute("items", list);
			session.remove("cid");
			 return "layout/shop";
		}
		
		//return "nhap/IndexNhap";
	}
	
	@RequestMapping("/product/detail/{id}")
	public String detail(Model model ,@PathVariable("id") Integer id) {
		Product item = productService.findByid(id);
		model.addAttribute("item", item);
     	return "layout/product-details";
	}
	
	@RequestMapping("/product/cart")
	public String cart(Model model) {
      return "layout/Cart";
	}
	
}
